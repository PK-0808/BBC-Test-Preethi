package runners;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",  // Path to feature files
    glue = "stepDefinitions",                  // Package containing step definitions
    plugin = {"pretty", "html:target/cucumber-report.html"},  // Generate HTML report
    monochrome = true                           // Make console output readable
)
public class TestRunner {
}
