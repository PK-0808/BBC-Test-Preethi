package stepDefinitions;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ApiStepDefinitions {

    // the below line defines a global variable "response" of type Response
    private Response response;

    // ==============================
    // Scenario 1: 
    // ==============================

    //below cucumber @Given step maps to the "Given" step in the feature file
    // the {string} is a placeholder which allows passing a URL dynamically
    //cucumber will replace {string} with "https://testapi.io/api/RMSTest/ibltest" from the feature file
    @Given("I send a GET request to {string}")
    // the below method sends a GET request to the specified URL
    //the method uses parameter string url that receives the URL from the feature file
    public void i_send_a_get_request_to(String url) {
       // Send a GET request to the specified URL
       // the response variable is assigned the response from the GET request
        response = RestAssured.get(url);
        
        // Print the response for debugging
        // the response is printed in a pretty format
        // the asPrettyString() method is used to print the response in a readable format
        // the response is printed in the console
        //System.out.println("\n API Response:\n" + response.getBody().asPrettyString());
    }
     //the cucumber step maps to the "Then" step in the feature file
    // the {int} is a placeholder which allows passing a status code dynamically
    //cucumber will replace {int} with 200 from the feature file
    @Then("I verify the response status code is {int}")

    //the below method verifies the status code of the response
    //the method uses parameter int statusCode that receives the status code from the feature file
    //the method uses the assertEquals method to compare the expected status code with the actual status code
    //if the status codes match, the test passes
    public void i_verify_the_response_status_code_is(int statusCode) {
        // assertEquals method is used to compare the expected status code with the actual status code
        // if the status codes match, the test passes
        assertEquals("Status code mismatch!", statusCode, response.getStatusCode());
    }
    
    @Then("I verify the response time is below {int} milliseconds")
    public void i_verify_the_response_time_is_below(int timeLimit) {
        // assertTrue method is used to verify that the response time is below the specified time limit
        // if the response time is below the time limit, the test passes
        assertTrue("Response time exceeded " + timeLimit + " ms!", response.getTime() < timeLimit);
    }

    // ==============================
    // Scenario 2: 
    // ==============================
    // In this scenario we will verify that the id field in the response is never null or empty
    // and that type field in episode the response is always "episode"
    @Then("I verify each schedule item's {string} field is never null or empty")
    public void i_verify_each_schedule_item_field_is_never_null_or_empty(String field) {
        JsonPath jsonPath = response.jsonPath();

        // Corrected JSON path: Extract "elements" list from "schedule"
        List<Map<String, Object>> elements = jsonPath.getList("schedule.elements");
        // the assertNotNull method is used to verify that the schedule.elements field is not null
        // the assertFalse method is used to verify that the schedule.elements list is not empty
        assertNotNull("'schedule.elements' field is missing in response!", elements);
        assertFalse("'schedule.elements' list is empty!", elements.isEmpty());
        //  below code loops through each item in the list
        for (Map<String, Object> item : elements) {
            Object value = item.get(field);
            assertNotNull("Field '" + field + "' is null!", value);
            assertFalse("Field '" + field + "' is empty!", value.toString().trim().isEmpty());
        }
    }

    @Then("I verify that the {string} in {string} for every item is always {string}")
    public void i_verify_that_field_in_object_for_every_item_is_always(String field, String object, String expectedValue) {
        JsonPath jsonPath = response.jsonPath();

        // Corrected JSON path: Extract "elements" list
        List<Map<String, Object>> elements = jsonPath.getList("schedule.elements");

        assertNotNull("'schedule.elements' field is missing in response!", elements);
        assertFalse("'schedule.elements' list is empty!", elements.isEmpty());
        // Loop through each item in the list
        for (Map<String, Object> item : elements) {
            Map<String, Object> nestedObject = (Map<String, Object>) item.get(object); // Extract "episode"
            assertNotNull("Object '" + object + "' is missing!", nestedObject);

            Object value = nestedObject.get(field);
            assertNotNull("Field '" + field + "' is null in '" + object + "'!", value);
            assertEquals("Field '" + field + "' does not match expected value: " + expectedValue, expectedValue, value.toString());
        }
    }

    // ==============================
    // Scenario 3: 
    // ==============================
    // In this scenario we will verify that the response contains a list of schedule items
    //  and that each schedule item has a non-empty "title" field 
    @Then("I verify that the {string} field in {string} is never null or empty")
    public void i_verify_that_field_in_object_is_never_null_or_empty(String field, String object) {
        JsonPath jsonPath = response.jsonPath();

        // Corrected JSON path: Extract "elements" list
        List<Map<String, Object>> elements = jsonPath.getList("schedule.elements");

        assertNotNull("'schedule.elements' field is missing in response!", elements);
        assertFalse("'schedule.elements' list is empty!", elements.isEmpty());

        for (Map<String, Object> item : elements) {
            Map<String, Object> nestedObject = (Map<String, Object>) item.get(object); // Extract "episode"
            assertNotNull("Object '" + object + "' is missing!", nestedObject);

            Object value = nestedObject.get(field);
            assertNotNull("Field '" + field + "' is null in '" + object + "'!", value);
            assertFalse("Field '" + field + "' is empty in '" + object + "'!", value.toString().trim().isEmpty());
        }
    }

    // ==============================
    // Scenario 4: 
    // ==============================
    //  In this scenario we will verify that only one episode in the list has a specific field value 
    @Then("I verify that only one episode in the list has {string} field in {string} as {string}")
    public void i_verify_only_one_episode_has_field_in_object_as(String field, String object, String expectedValue) {
        JsonPath jsonPath = response.jsonPath();

        // Extract the list of episodes from schedule elements
        List<Map<String, Object>> elements = jsonPath.getList("schedule.elements");

        assertNotNull("'schedule.elements' field is missing in response!", elements);
        assertFalse("'schedule.elements' list is empty!", elements.isEmpty());

        int liveCount = 0;

        for (Map<String, Object> item : elements) {
            Map<String, Object> nestedObject = (Map<String, Object>) item.get(object); // Extract "episode"
            if (nestedObject != null && nestedObject.containsKey(field)) {
                Object value = nestedObject.get(field);
                if (value.toString().equalsIgnoreCase(expectedValue)) {
                    liveCount++;
                }
            }
        }

        assertEquals("Expected only one episode with '" + field + "' as '" + expectedValue + "', but found " + liveCount, 1, liveCount);
    }

    // ==============================
    // Scenario 5: 
    // ==============================
    // In this scenario we will verify that the transmission start time is before the transmission end time for each schedule item
    @Then("I verify that the {string} is before {string}")
    public void i_verify_that_the_is_before(String startField, String endField) {
        JsonPath jsonPath = response.jsonPath();
    
        // Extract the list of schedule elements
        List<Map<String, Object>> elements = jsonPath.getList("schedule.elements");
    
        assertNotNull("'schedule.elements' field is missing in response!", elements);
        assertFalse("'schedule.elements' list is empty!", elements.isEmpty());
    
        for (Map<String, Object> item : elements) {
            Object startDateStr = item.get(startField);
            Object endDateStr = item.get(endField);
    
            assertNotNull("'" + startField + "' field is missing or null!", startDateStr);
            assertNotNull("'" + endField + "' field is missing or null!", endDateStr);
    
            try {
                Instant startDate = Instant.parse(startDateStr.toString());
                Instant endDate = Instant.parse(endDateStr.toString());
    
                assertTrue("'" + startField + "' (" + startDate + ") is NOT before '" + endField + "' (" + endDate + ")!",
                        startDate.isBefore(endDate));
    
            } catch (DateTimeParseException e) {
                fail("One of the date fields ('" + startField + "' or '" + endField + "') is in an invalid format!");
            }
        }
    }
    
    // ==============================
    // Scenario 6:
    // ==============================
    // In this scenario we will verify that the response header contains a valid Date field
    @Then("I verify that the response header contains a valid {string} field")
    public void i_verify_that_the_response_header_contains_a_valid_field(String headerName) {
        String dateHeader = response.getHeader(headerName);
        assertNotNull("Response header '" + headerName + "' is missing!", dateHeader);

    }

    // ==============================
    // Scenario 7: 
    // ==============================
    // In this scenario we will verify that the response contains an error object with specific properties
    // and the error object has the properties details and http_response_code  
    @Then("I verify the response contains an {string} object with {string} and {string} properties")
    public void i_verify_the_response_contains_an_object_with_and_properties(String object, String field1, String field2) {
        JsonPath jsonPath = response.jsonPath();

        // Extract the error object from the response
        Map<String, Object> errorObject = jsonPath.getMap(object);

        // Assert that the error object is present
        assertNotNull("Expected error object '" + object + "' is missing in response!", errorObject);

        // Assert that the expected properties exist in the error object
        assertTrue("'" + object + "' object does not contain expected field '" + field1 + "'!", errorObject.containsKey(field1));
        assertTrue("'" + object + "' object does not contain expected field '" + field2 + "'!", errorObject.containsKey(field2));

        // Print error object for debugging
        System.out.println("Error object contains expected properties: " + errorObject);
    }   

}